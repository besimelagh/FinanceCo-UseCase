@echo off
cd /d "%~dp0"
echo Running FinanceCo ETL Pipeline...
echo.
py etl/pipeline.py
echo.
if %ERRORLEVEL% NEQ 0 (
    echo Pipeline failed with error code %ERRORLEVEL%.
) else (
    echo Pipeline completed successfully.
)
pause
