"""
Generates regulatory_metrics_Q1_2026.parquet
Run once as part of demo setup.
"""
import pandas as pd
from pathlib import Path

records = [
    # metric_id, metric_name, category, value, threshold, unit, status, reporting_period, regulator, notes
    ("REG-001","Solvency Capital Ratio","Solvency",248.3,100.0,"%","Pass","Q1-2026","EIOPA","Well above 100% SCR minimum; strong capital position"),
    ("REG-002","Minimum Capital Requirement Coverage","Solvency",312.7,100.0,"%","Pass","Q1-2026","EIOPA","MCR coverage comfortably above regulatory floor"),
    ("REG-003","Claims Settlement Ratio (90-day)","Claims",78.4,85.0,"%","Fail","Q1-2026","FCA","Below 85% threshold; escalation required"),
    ("REG-004","Average Days to Settle Claims","Claims",22.6,30.0,"days","Pass","Q1-2026","FCA","Within 30-day SLA for settled claims"),
    ("REG-005","Fraud Detection Rate","AML/Fraud",4.2,3.0,"%","Amber","Q1-2026","FCA","Above 3% fraud detection target; review flagged claims"),
    ("REG-006","Regulatory Reporting Timeliness","Reporting",96.5,95.0,"%","Pass","Q1-2026","FCA","Reports submitted on time; minor delay in Feb batch"),
    ("REG-007","Data Accuracy Score (Financial Reports)","Reporting",97.8,98.0,"%","Amber","Q1-2026","FCA","Marginally below 98% accuracy target; data quality review initiated"),
    ("REG-008","Policyholder Complaint Resolution Rate","Customer",91.2,90.0,"%","Pass","Q1-2026","FCA","Above 90% resolution within 8 weeks"),
    ("REG-009","Anti-Money Laundering Transaction Screening","AML/Fraud",100.0,100.0,"%","Pass","Q1-2026","HMRC","All transactions screened against sanctions list"),
    ("REG-010","Premium Adequacy Ratio","Pricing",103.4,100.0,"%","Pass","Q1-2026","EIOPA","Premiums above technical provisions; adequate pricing"),
    ("REG-011","Reinsurance Recoverables as % of Total Claims","Reinsurance",18.7,20.0,"%","Amber","Q1-2026","EIOPA","Slightly below 20% recovery target; reinsurance treaty review"),
    ("REG-012","Conduct Risk Score","Conduct",82.0,80.0,"%","Pass","Q1-2026","FCA","Above minimum conduct risk threshold"),
    ("REG-013","GDPR Data Subject Request Compliance","Data Privacy",98.9,100.0,"%","Amber","Q1-2026","ICO","3 requests not completed within 30-day window"),
    ("REG-014","IT System Availability (Core ETL)","Operations",94.2,99.5,"%","Fail","Q1-2026","Internal","Legacy ETL system outages causing data delays — primary driver of this project"),
    ("REG-015","Investment Concentration Risk","Investment",14.8,15.0,"%","Pass","Q1-2026","EIOPA","Asset concentration below 15% limit per issuer"),
]

df = pd.DataFrame(records, columns=[
    "metric_id","metric_name","category","value","threshold","unit",
    "status","reporting_period","regulator","notes"
])

out = Path(__file__).parent / "regulatory_metrics_Q1_2026.parquet"
df.to_parquet(out, index=False)
print(f"Generated: {out}  ({len(df)} metrics)")
