"""
PIPELINE ORCHESTRATOR
=====================
Runs the full FinanceCo ETL pipeline end-to-end:

  1. EXTRACT  — read CSV / XML / Parquet source files
  2. LOAD RAW — persist as-is to raw_* tables (audit trail)
  3. TRANSFORM — clean, enrich, join, aggregate
  4. LOAD CURATED — persist cleaned data to curated_* tables
  5. LOAD AGGREGATED — persist KPI tables to agg_* tables
  6. REPORT — print a summary to the console and save CSV reports

Usage:
    cd demo/
    py etl/pipeline.py
"""
import logging
import sys
import time
from pathlib import Path
from datetime import datetime

import pandas as pd

# ── Add demo root to path so sibling modules resolve correctly ────────────────
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import REPORTS_DIR, DB_PATH
import extract as E
import transform as T
import load as L

# ─── Logging setup ───────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("ETL.Pipeline")

SEPARATOR = "─" * 72


def banner(msg: str) -> None:
    log.info(SEPARATOR)
    log.info(f"  {msg}")
    log.info(SEPARATOR)


# ─────────────────────────────────────────────────────────────────────────────
def run() -> None:
    start = time.time()
    run_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    banner(f"FinanceCo ETL Pipeline  |  run started: {run_ts}")

    # ── STEP 1: EXTRACT ───────────────────────────────────────────────────────
    banner("STEP 1 / 5 — EXTRACT")
    raw = E.extract_all()
    log.info(f"Extracted {len(raw)} source datasets")

    # ── STEP 2: LOAD RAW ─────────────────────────────────────────────────────
    banner("STEP 2 / 5 — LOAD RAW (audit layer)")
    L.load_raw(raw)

    # ── STEP 3: TRANSFORM ────────────────────────────────────────────────────
    banner("STEP 3 / 5 — TRANSFORM")

    curated_claims     = T.transform_claims(raw["claims"])
    curated_customers  = T.transform_customers(raw["customers"])
    curated_financial  = T.transform_financial(raw["financial"])
    curated_regulatory = T.transform_regulatory(raw["regulatory"])

    # Joined views
    policyholder_360 = T.build_policyholder_360(curated_claims, curated_customers)

    # Aggregations
    claims_summary   = T.build_claims_summary(curated_claims)
    financial_kpis   = T.build_financial_kpis(curated_financial)
    compliance_score = T.build_compliance_scorecard(curated_regulatory)

    # ── STEP 4: LOAD CURATED ─────────────────────────────────────────────────
    banner("STEP 4 / 5 — LOAD CURATED")
    L.load_curated({
        "claims":           curated_claims,
        "customers":        curated_customers,
        "financial":        curated_financial,
        "regulatory":       curated_regulatory,
        "policyholder_360": policyholder_360,
    })

    # ── STEP 5: LOAD AGGREGATED ───────────────────────────────────────────────
    banner("STEP 5 / 5 — LOAD AGGREGATED")
    L.load_aggregated({
        "claims_summary":    claims_summary,
        "financial_kpis":    financial_kpis,
        "compliance_score":  compliance_score,
    })

    # ── REPORTS ───────────────────────────────────────────────────────────────
    banner("GENERATING REPORTS")
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)

    _save_report(claims_summary,   "claims_summary.csv")
    _save_report(financial_kpis,   "financial_kpis.csv")
    _save_report(compliance_score, "compliance_scorecard.csv")
    _save_report(policyholder_360, "policyholder_360.csv")

    # ── SUMMARY ───────────────────────────────────────────────────────────────
    banner("PIPELINE SUMMARY")
    stats = L.table_stats()
    print(stats.to_string(index=False))

    elapsed = time.time() - start
    _print_kpi_highlights(curated_claims, curated_financial, curated_regulatory)

    log.info(SEPARATOR)
    log.info(f"  Pipeline completed in {elapsed:.2f}s")
    log.info(f"  Database: {DB_PATH}")
    log.info(f"  Reports:  {REPORTS_DIR}")
    log.info(SEPARATOR)


# ─── Helpers ──────────────────────────────────────────────────────────────────
def _save_report(df: pd.DataFrame, filename: str) -> None:
    path = REPORTS_DIR / filename
    df.to_csv(path, index=False)
    log.info(f"[REPORT] Saved: {path.name} ({len(df):,} rows)")


def _print_kpi_highlights(claims: pd.DataFrame,
                           financial: pd.DataFrame,
                           regulatory: pd.DataFrame) -> None:
    print("\n" + "═" * 72)
    print("  KPI HIGHLIGHTS — Q1 2026")
    print("═" * 72)

    total_claims  = len(claims)
    open_claims   = (claims["status"].isin(["In-Review", "Open"])).sum()
    settled       = (claims["status"] == "Settled").sum()
    rejected      = (claims["status"] == "Rejected").sum()
    fraud_flags   = claims["fraud_flag"].sum() if claims["fraud_flag"].dtype == bool else 0
    total_claimed = claims["claim_amount"].sum()
    total_settled = claims["settlement_amount"].sum()

    print(f"\n  CLAIMS (Q1 2026)")
    print(f"    Total claims submitted : {total_claims}")
    print(f"    Settled                : {settled}  ({settled/total_claims*100:.0f}%)")
    print(f"    In-Review / Open       : {open_claims}  ({open_claims/total_claims*100:.0f}%)")
    print(f"    Rejected               : {rejected}")
    print(f"    Fraud-flagged          : {int(fraud_flags)}")
    print(f"    Total claim value      : £{total_claimed:,.0f}")
    print(f"    Total settled value    : £{total_settled:,.0f}")

    avg_settle_days = claims["days_to_settle"].mean()
    print(f"    Avg. days to settle    : {avg_settle_days:.1f}")

    print(f"\n  FINANCIAL (Full-Year 2025)")
    fy = financial[financial["year"] == 2025]
    print(f"    Total premiums         : £{fy['premium_collected'].sum():,.0f}")
    print(f"    Total claims paid      : £{fy['claims_paid'].sum():,.0f}")
    print(f"    Net profit (FY)        : £{fy['net_profit'].sum():,.0f}")
    print(f"    Avg. payout ratio      : {fy['payout_ratio_pct'].mean():.1f}%")
    print(f"    Avg. combined ratio    : {fy['combined_ratio_pct'].mean():.1f}%")
    worst_month = fy.loc[fy["payout_ratio_pct"].idxmax(), "month_name"]
    print(f"    Worst payout month     : {worst_month}")

    print(f"\n  REGULATORY COMPLIANCE (Q1 2026)")
    total_r = len(regulatory)
    green   = (regulatory["rag_status"] == "Green").sum()
    amber   = (regulatory["rag_status"] == "Amber").sum()
    red     = (regulatory["rag_status"] == "Red").sum()
    score   = round(green / total_r * 100, 1)
    print(f"    Overall score          : {score}%  ({green} Pass / {amber} Amber / {red} Fail)")
    fails   = regulatory[regulatory["rag_status"] == "Red"]["metric_name"].tolist()
    if fails:
        print(f"    ⚠ Failed metrics       : {', '.join(fails)}")
    print()


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    run()
