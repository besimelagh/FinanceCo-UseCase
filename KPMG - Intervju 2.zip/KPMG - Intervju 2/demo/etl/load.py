"""
LOAD layer — writes DataFrames to the SQLite data platform.

Three zones mirror Azure Data Lake / Synapse zones:
  raw_*       →  as-extracted (string columns, no transformations)
  curated_*   →  typed, cleaned, enriched
  agg_*       →  aggregated KPIs ready for dashboard queries
"""
import logging
import sqlite3
from pathlib import Path

import pandas as pd

from config import DB_PATH

log = logging.getLogger("ETL.Load")


# ─────────────────────────────────────────────────────────────────────────────
def _get_conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(DB_PATH)


def _write(df: pd.DataFrame, table_name: str, if_exists: str = "replace") -> None:
    with _get_conn() as conn:
        df.to_sql(table_name, conn, if_exists=if_exists, index=False)
    log.info(f"[LOAD] → {table_name}: {len(df):,} rows written to {DB_PATH.name}")


# ─── Raw zone ─────────────────────────────────────────────────────────────────
def load_raw(raw_dfs: dict[str, pd.DataFrame]) -> None:
    log.info("[LOAD] Writing raw zone …")
    for name, df in raw_dfs.items():
        # Stringify everything to preserve raw fidelity
        _write(df.astype(str), f"raw_{name}")


# ─── Curated zone ─────────────────────────────────────────────────────────────
def load_curated(curated_dfs: dict[str, pd.DataFrame]) -> None:
    log.info("[LOAD] Writing curated zone …")
    for name, df in curated_dfs.items():
        _write(df, f"curated_{name}")


# ─── Aggregated zone ──────────────────────────────────────────────────────────
def load_aggregated(agg_dfs: dict[str, pd.DataFrame]) -> None:
    log.info("[LOAD] Writing aggregated zone …")
    for name, df in agg_dfs.items():
        _write(df, f"agg_{name}")


# ─── Introspection helper ─────────────────────────────────────────────────────
def list_tables() -> list[str]:
    with _get_conn() as conn:
        cur = conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        return [r[0] for r in cur.fetchall()]


def table_stats() -> pd.DataFrame:
    tables = list_tables()
    rows = []
    with _get_conn() as conn:
        for t in tables:
            count = conn.execute(f"SELECT COUNT(*) FROM [{t}]").fetchone()[0]
            cols  = conn.execute(f"PRAGMA table_info([{t}])").fetchall()
            zone  = t.split("_")[0]
            rows.append({"table": t, "zone": zone, "rows": count, "columns": len(cols)})
    return pd.DataFrame(rows)
