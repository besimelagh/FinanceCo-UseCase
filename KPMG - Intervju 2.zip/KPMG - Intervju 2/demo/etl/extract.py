"""
EXTRACT layer — reads raw source files into pandas DataFrames.
Supports CSV, XML, and Parquet.  Each function logs source metadata
(row count, columns, file size) before returning.
"""
import logging
import xml.etree.ElementTree as ET
import pandas as pd
from pathlib import Path
from config import (
    CLAIMS_CSV, CUSTOMERS_XML, FINANCIAL_CSV, REGULATORY_PQ
)

log = logging.getLogger("ETL.Extract")


# ─────────────────────────────────────────────────────────────────────────────
def _log_source(name: str, path: Path, df: pd.DataFrame) -> None:
    size_kb = path.stat().st_size / 1024
    log.info(
        f"[EXTRACT] {name}: {len(df):,} rows × {len(df.columns)} cols "
        f"| file: {path.name} ({size_kb:.1f} KB)"
    )


# ─────────────────────────────────────────────────────────────────────────────
def extract_claims() -> pd.DataFrame:
    """Read claims CSV — semicolon or comma delimited, auto-detected."""
    log.info(f"Reading claims from: {CLAIMS_CSV}")
    df = pd.read_csv(CLAIMS_CSV, dtype=str)   # read as str to preserve raw fidelity
    _log_source("Claims", CLAIMS_CSV, df)
    return df


# ─────────────────────────────────────────────────────────────────────────────
def extract_customers() -> pd.DataFrame:
    """
    Parse customer XML into a flat DataFrame.
    Handles nested <address> and <Policy> child elements.
    """
    log.info(f"Reading customers from: {CUSTOMERS_XML}")
    tree = ET.parse(CUSTOMERS_XML)
    root = tree.getroot()

    rows = []
    for cust in root.findall("Customer"):
        addr = cust.find("Address") or cust.find("address")
        pol  = cust.find("Policy")

        def get(node, tag, default=""):
            if node is None:
                return default
            el = node.find(tag)
            return el.text.strip() if el is not None and el.text else default

        row = {
            "customer_id":        get(cust, "customer_id"),
            "first_name":         get(cust, "first_name"),
            "last_name":          get(cust, "last_name"),
            "date_of_birth":      get(cust, "date_of_birth"),
            "gender":             get(cust, "gender"),
            "email":              get(cust, "email"),
            "phone":              get(cust, "phone"),
            "street":             get(addr, "street"),
            "city":               get(addr, "city"),
            "postcode":           get(addr, "postcode"),
            "country":            get(addr, "country"),
            "policy_id":          get(pol,  "policy_id"),
            "policy_type":        get(pol,  "policy_type"),
            "annual_premium":     get(pol,  "annual_premium"),
            "sum_insured":        get(pol,  "sum_insured"),
            "policy_start_date":  get(pol,  "start_date"),
            "policy_end_date":    get(pol,  "end_date"),
            "policy_status":      get(pol,  "status"),
            "payment_frequency":  get(pol,  "payment_frequency"),
        }
        rows.append(row)

    df = pd.DataFrame(rows)
    _log_source("Customers", CUSTOMERS_XML, df)
    return df


# ─────────────────────────────────────────────────────────────────────────────
def extract_financial() -> pd.DataFrame:
    """Read financial metrics CSV."""
    log.info(f"Reading financial metrics from: {FINANCIAL_CSV}")
    df = pd.read_csv(FINANCIAL_CSV, dtype=str)
    _log_source("Financial", FINANCIAL_CSV, df)
    return df


# ─────────────────────────────────────────────────────────────────────────────
def extract_regulatory() -> pd.DataFrame:
    """Read regulatory metrics Parquet file."""
    log.info(f"Reading regulatory metrics from: {REGULATORY_PQ}")
    df = pd.read_parquet(REGULATORY_PQ)
    _log_source("Regulatory", REGULATORY_PQ, df)
    return df


# ─────────────────────────────────────────────────────────────────────────────
def extract_all() -> dict[str, pd.DataFrame]:
    """Run all extracts and return a named dict of raw DataFrames."""
    return {
        "claims":     extract_claims(),
        "customers":  extract_customers(),
        "financial":  extract_financial(),
        "regulatory": extract_regulatory(),
    }
