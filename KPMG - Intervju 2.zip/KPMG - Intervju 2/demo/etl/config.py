"""
ETL Configuration — paths, schema names, logging level.
All path resolution is relative to the demo/ root so the demo
is portable regardless of where it is cloned.
"""
from pathlib import Path

# ── Paths ────────────────────────────────────────────────────────────────────
DEMO_ROOT   = Path(__file__).resolve().parent.parent
SOURCES     = DEMO_ROOT / "data_sources"
DB_PATH     = DEMO_ROOT / "data_platform" / "financedb.db"
REPORTS_DIR = DEMO_ROOT / "reports"

CLAIMS_CSV      = SOURCES / "claims"     / "claims_Q1_2026.csv"
CUSTOMERS_XML   = SOURCES / "customer"   / "customers.xml"
FINANCIAL_CSV   = SOURCES / "financial"  / "financial_metrics_2025.csv"
REGULATORY_PQ   = SOURCES / "regulatory" / "regulatory_metrics_Q1_2026.parquet"

# ── Data Platform layer names (SQLite schemas via table prefixes) ─────────────
RAW_CLAIMS      = "raw_claims"
RAW_CUSTOMERS   = "raw_customers"
RAW_FINANCIAL   = "raw_financial"
RAW_REGULATORY  = "raw_regulatory"

CURATED_CLAIMS      = "curated_claims"
CURATED_CUSTOMERS   = "curated_customers"
CURATED_FINANCIAL   = "curated_financial"
CURATED_REGULATORY  = "curated_regulatory"
CURATED_POLICYHOLDER_VIEW = "curated_policyholder_360"

AGG_CLAIMS_SUMMARY  = "agg_claims_summary"
AGG_FINANCIAL_KPIS  = "agg_financial_kpis"
AGG_COMPLIANCE_SCORE= "agg_compliance_score"

# ── Quality thresholds ───────────────────────────────────────────────────────
MAX_NULL_PCT        = 5.0    # fail if any column exceeds this % nulls
MAX_DUPLICATE_PCT   = 1.0    # fail if duplicate rows exceed this %
CLAIM_AMOUNT_MIN    = 0.0
CLAIM_AMOUNT_MAX    = 1_000_000.0
