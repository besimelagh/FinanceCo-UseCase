"""
TRANSFORM layer — cleans, validates, enriches and joins raw DataFrames.

Three sub-layers mirror the data platform zones:
  1. _clean_*   →  type casting, null handling, deduplication  (curated)
  2. _enrich_*  →  business rules, derived columns             (curated)
  3. build_*    →  aggregations / KPI computations             (aggregated)
"""
import logging
import pandas as pd
import numpy as np
from config import (
    MAX_NULL_PCT, MAX_DUPLICATE_PCT,
    CLAIM_AMOUNT_MIN, CLAIM_AMOUNT_MAX,
)

log = logging.getLogger("ETL.Transform")


# ─── Data Quality Check ───────────────────────────────────────────────────────
def _dq_check(df: pd.DataFrame, name: str) -> pd.DataFrame:
    """Log data quality metrics; flag columns that breach thresholds."""
    total = len(df)
    issues = []
    for col in df.columns:
        null_pct = df[col].isna().sum() / total * 100
        if null_pct > MAX_NULL_PCT:
            issues.append(f"  ⚠ {col}: {null_pct:.1f}% nulls (threshold {MAX_NULL_PCT}%)")

    dup_pct = df.duplicated().sum() / total * 100
    if dup_pct > MAX_DUPLICATE_PCT:
        issues.append(f"  ⚠ Duplicate rows: {dup_pct:.1f}% (threshold {MAX_DUPLICATE_PCT}%)")

    if issues:
        log.warning(f"[DQ] {name} quality issues:\n" + "\n".join(issues))
    else:
        log.info(f"[DQ] {name}: all checks passed ({total:,} rows)")
    return df


# ═══════════════════════════════════════════════════════════════════════════════
# CLAIMS
# ═══════════════════════════════════════════════════════════════════════════════
def transform_claims(raw: pd.DataFrame) -> pd.DataFrame:
    log.info("[TRANSFORM] Claims — clean & enrich")
    df = raw.copy()

    # ── Cast types ──
    df["claim_date"]       = pd.to_datetime(df["claim_date"],       errors="coerce")
    df["settlement_date"]  = pd.to_datetime(df["settlement_date"],  errors="coerce")
    df["claim_amount"]     = pd.to_numeric(df["claim_amount"],      errors="coerce")
    df["settlement_amount"]= pd.to_numeric(df["settlement_amount"], errors="coerce")
    df["days_to_settle"]   = pd.to_numeric(df["days_to_settle"],    errors="coerce")
    df["fraud_flag"]       = df["fraud_flag"].str.strip().str.upper().map({"Y": True, "N": False})

    # ── Normalise strings ──
    df["status"]           = df["status"].str.strip().str.title()
    df["claim_type"]       = df["claim_type"].str.strip().str.title()
    df["handler_dept"]     = df["handler_dept"].str.strip()

    # ── Validate amounts ──
    out_of_range = (
        (df["claim_amount"] < CLAIM_AMOUNT_MIN) |
        (df["claim_amount"] > CLAIM_AMOUNT_MAX)
    )
    if out_of_range.any():
        log.warning(f"[DQ] Claims: {out_of_range.sum()} rows with out-of-range claim_amount — nulled")
        df.loc[out_of_range, "claim_amount"] = np.nan

    # ── Derived columns ──
    df["claim_quarter"] = df["claim_date"].dt.to_period("Q").astype(str)
    df["claim_month"]   = df["claim_date"].dt.to_period("M").astype(str)
    df["claim_year"]    = df["claim_date"].dt.year

    # Settlement gap (computed from dates if days_to_settle is missing)
    mask = df["days_to_settle"].isna() & df["settlement_date"].notna()
    df.loc[mask, "days_to_settle"] = (
        df.loc[mask, "settlement_date"] - df.loc[mask, "claim_date"]
    ).dt.days

    # Recovery ratio
    df["recovery_ratio"] = (
        df["settlement_amount"] / df["claim_amount"]
    ).round(4)

    # Is large claim (>50k)
    df["is_large_claim"] = df["claim_amount"] > 50_000

    # ── Remove true duplicates (same claim_id) ──
    before = len(df)
    df = df.drop_duplicates(subset=["claim_id"], keep="first")
    if len(df) < before:
        log.warning(f"[DQ] Removed {before - len(df)} duplicate claim IDs")

    _dq_check(df, "Claims")
    log.info(f"[TRANSFORM] Claims done: {len(df):,} rows, {len(df.columns)} cols")
    return df


# ═══════════════════════════════════════════════════════════════════════════════
# CUSTOMERS
# ═══════════════════════════════════════════════════════════════════════════════
def transform_customers(raw: pd.DataFrame) -> pd.DataFrame:
    log.info("[TRANSFORM] Customers — clean & enrich")
    df = raw.copy()

    df["date_of_birth"]     = pd.to_datetime(df["date_of_birth"],    errors="coerce")
    df["policy_start_date"] = pd.to_datetime(df["policy_start_date"],errors="coerce")
    df["policy_end_date"]   = pd.to_datetime(df["policy_end_date"],  errors="coerce")
    df["annual_premium"]    = pd.to_numeric(df["annual_premium"],    errors="coerce")
    df["sum_insured"]       = pd.to_numeric(df["sum_insured"],       errors="coerce")

    # Derived
    today = pd.Timestamp("today").normalize()
    df["age"] = ((today - df["date_of_birth"]).dt.days / 365.25).astype(int, errors="ignore")
    df["policy_duration_years"] = (
        (df["policy_end_date"] - df["policy_start_date"]).dt.days / 365.25
    ).round(1)
    df["days_until_expiry"] = (df["policy_end_date"] - today).dt.days
    df["full_name"] = df["first_name"].str.strip() + " " + df["last_name"].str.strip()
    df["email"] = df["email"].str.lower().str.strip()

    # Risk band by age
    df["age_band"] = pd.cut(
        df["age"],
        bins=[0, 30, 45, 60, 100],
        labels=["18-30", "31-45", "46-60", "60+"]
    )

    before = len(df)
    df = df.drop_duplicates(subset=["customer_id"], keep="first")
    if len(df) < before:
        log.warning(f"[DQ] Removed {before - len(df)} duplicate customer IDs")

    _dq_check(df, "Customers")
    log.info(f"[TRANSFORM] Customers done: {len(df):,} rows")
    return df


# ═══════════════════════════════════════════════════════════════════════════════
# FINANCIAL
# ═══════════════════════════════════════════════════════════════════════════════
def transform_financial(raw: pd.DataFrame) -> pd.DataFrame:
    log.info("[TRANSFORM] Financial — clean & enrich")
    df = raw.copy()

    numeric_cols = [
        "premium_collected","claims_paid","operating_costs","investment_income",
        "reinsurance_cost","net_profit","total_policies_active","new_policies",
        "lapsed_policies","payout_ratio_pct","loss_ratio_pct","combined_ratio_pct",
        "solvency_capital_requirement","solvency_ratio_pct",
    ]
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["year"]  = df["year"].astype(int)
    df["month"] = df["month"].astype(int)

    # Period key
    df["period_key"] = df["year"].astype(str) + "-" + df["month"].astype(str).str.zfill(2)

    # YTD columns
    df = df.sort_values(["year", "month"])
    for col in ["premium_collected", "claims_paid", "net_profit"]:
        df[f"{col}_ytd"] = df.groupby("year")[col].cumsum()

    # Margin
    df["net_margin_pct"] = (df["net_profit"] / df["premium_collected"] * 100).round(2)

    # Policy churn rate
    df["churn_rate_pct"] = (df["lapsed_policies"] / df["total_policies_active"] * 100).round(2)

    _dq_check(df, "Financial")
    log.info(f"[TRANSFORM] Financial done: {len(df):,} rows")
    return df


# ═══════════════════════════════════════════════════════════════════════════════
# REGULATORY
# ═══════════════════════════════════════════════════════════════════════════════
def transform_regulatory(raw: pd.DataFrame) -> pd.DataFrame:
    log.info("[TRANSFORM] Regulatory — clean & enrich")
    df = raw.copy()

    df["value"]     = pd.to_numeric(df["value"],     errors="coerce")
    df["threshold"] = pd.to_numeric(df["threshold"], errors="coerce")

    # Variance from threshold
    df["variance_from_threshold"] = (df["value"] - df["threshold"]).round(2)
    df["pct_vs_threshold"] = ((df["value"] / df["threshold"]) * 100).round(1)

    # Compliance colour (RAG)
    def rag(row):
        if row["status"] == "Pass":
            return "Green"
        elif row["status"] == "Amber":
            return "Amber"
        else:
            return "Red"
    df["rag_status"] = df.apply(rag, axis=1)

    # Numeric RAG score (Green=2, Amber=1, Red=0) for aggregation
    df["rag_score"] = df["rag_status"].map({"Green": 2, "Amber": 1, "Red": 0})

    _dq_check(df, "Regulatory")
    log.info(f"[TRANSFORM] Regulatory done: {len(df):,} rows")
    return df


# ═══════════════════════════════════════════════════════════════════════════════
# JOINED / ENRICHED: Policyholder 360 view
# ═══════════════════════════════════════════════════════════════════════════════
def build_policyholder_360(claims: pd.DataFrame, customers: pd.DataFrame) -> pd.DataFrame:
    """Join curated claims with curated customers to create unified view."""
    log.info("[TRANSFORM] Building Policyholder 360 view")
    merged = claims.merge(
        customers[[
            "customer_id","full_name","age","age_band","city","country",
            "policy_type","annual_premium","sum_insured","policy_status",
            "days_until_expiry"
        ]],
        on="customer_id", how="left"
    )
    merged["premium_to_claim_ratio"] = (
        merged["annual_premium"] / merged["claim_amount"]
    ).round(4)
    log.info(f"[TRANSFORM] Policyholder 360: {len(merged):,} rows (match rate: "
             f"{merged['full_name'].notna().mean()*100:.1f}%)")
    return merged


# ═══════════════════════════════════════════════════════════════════════════════
# AGGREGATED: Claims Summary KPIs
# ═══════════════════════════════════════════════════════════════════════════════
def build_claims_summary(claims: pd.DataFrame) -> pd.DataFrame:
    log.info("[TRANSFORM] Building claims summary aggregation")
    summary = (
        claims.groupby(["claim_type", "status"])
        .agg(
            total_claims        =("claim_id",         "count"),
            total_claim_value   =("claim_amount",     "sum"),
            total_settled_value =("settlement_amount","sum"),
            avg_claim_amount    =("claim_amount",     "mean"),
            avg_days_to_settle  =("days_to_settle",   "mean"),
            fraud_count         =("fraud_flag",        lambda x: x.sum() if x.dtype == bool else (x == True).sum()),
        )
        .reset_index()
        .round(2)
    )
    summary["settlement_rate_pct"] = (
        summary["total_settled_value"] / summary["total_claim_value"] * 100
    ).round(1)
    log.info(f"[TRANSFORM] Claims summary: {len(summary):,} rows")
    return summary


# ═══════════════════════════════════════════════════════════════════════════════
# AGGREGATED: Financial KPIs
# ═══════════════════════════════════════════════════════════════════════════════
def build_financial_kpis(financial: pd.DataFrame) -> pd.DataFrame:
    log.info("[TRANSFORM] Building financial KPIs")
    kpis = financial[[
        "period_key","year","month_name",
        "premium_collected","claims_paid","net_profit",
        "payout_ratio_pct","loss_ratio_pct","combined_ratio_pct",
        "solvency_ratio_pct","net_margin_pct","churn_rate_pct",
        "premium_collected_ytd","claims_paid_ytd","net_profit_ytd",
    ]].copy()

    # Traffic-light flags for dashboard
    kpis["payout_flag"] = kpis["payout_ratio_pct"].apply(
        lambda x: "Red" if x > 70 else ("Amber" if x > 60 else "Green"))
    kpis["solvency_flag"] = kpis["solvency_ratio_pct"].apply(
        lambda x: "Red" if x < 130 else ("Amber" if x < 160 else "Green"))
    kpis["margin_flag"] = kpis["net_margin_pct"].apply(
        lambda x: "Red" if x < 5 else ("Amber" if x < 12 else "Green"))

    log.info(f"[TRANSFORM] Financial KPIs: {len(kpis):,} rows")
    return kpis


# ═══════════════════════════════════════════════════════════════════════════════
# AGGREGATED: Compliance Score Card
# ═══════════════════════════════════════════════════════════════════════════════
def build_compliance_scorecard(regulatory: pd.DataFrame) -> pd.DataFrame:
    log.info("[TRANSFORM] Building compliance scorecard")
    total   = len(regulatory)
    n_pass  = (regulatory["rag_status"] == "Green").sum()
    n_amber = (regulatory["rag_status"] == "Amber").sum()
    n_fail  = (regulatory["rag_status"] == "Red").sum()

    by_category = (
        regulatory.groupby("category")
        .agg(
            metrics_count   =("metric_id",  "count"),
            avg_rag_score   =("rag_score",  "mean"),
            pass_count      =("rag_status", lambda x: (x == "Green").sum()),
            amber_count     =("rag_status", lambda x: (x == "Amber").sum()),
            fail_count      =("rag_status", lambda x: (x == "Red").sum()),
        )
        .reset_index()
    )
    by_category["category_score_pct"] = (
        by_category["avg_rag_score"] / 2 * 100
    ).round(1)

    overall_score = round(n_pass / total * 100, 1)
    log.info(
        f"[TRANSFORM] Compliance: {n_pass} Pass / {n_amber} Amber / {n_fail} Fail "
        f"→ Overall score: {overall_score}%"
    )
    return by_category
